
# Heart in Action — uOttawa (Production-Ready Static Site)

World-class, accessible, fast static website. No build tools required (perfect for GitHub Pages).

## Files you edit most
- `data/site.json` — fundraising goal + raised + KPIs
- `data/events.json` — list of events (cards auto-render)
- `data/members.json` — founders (cards auto-render)
- `assets/` — images (logo, photos)

## Add an event (example)
Duplicate an object in `data/events.json`:
```json
{
  "title": "New Event",
  "date": "2025-10-10",
  "location": "SITE Atrium",
  "image": "assets/my-event.jpg",
  "description": "Short summary."
}
```

## 100% GitHub Workflow
1. Create a GitHub repo (e.g., `heart-in-action`).
2. Upload all files via web (**Add file → Upload files**). Commit.
3. Settings → **Pages** → Branch: `main`, Folder: `/` → Save.
4. Your site goes live. To update, edit JSON files directly on GitHub and commit.

## Notes
- Progress bar & KPIs update from `data/site.json` only (no backend needed).
- Images are lazy-loaded for performance.
- Accessible focus states and ARIA on progressbar.
- SEO/OG meta + JSON-LD added for professional previews.
