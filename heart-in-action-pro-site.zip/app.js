
// ============================================================================
// Heart in Action — app.js (Beginner-Friendly Comments)
// ----------------------------------------------------------------------------
// This file powers all dynamic behavior on the site. It uses *vanilla* JS
// so you don't need React/Vue and you can host on GitHub Pages (no server).
//
// Key ideas:
// 1) We store editable data in /data/*.json so you can update content on GitHub.
// 2) When a page loads, we fetch the JSON and render sections (goal, events, members).
// 3) We add small accessibility and UX enhancements (active nav, year, etc.).
// ============================================================================

document.addEventListener('DOMContentLoaded', async () => {
  // Highlight the active navigation item based on current file name
  const map = { 'index.html':'nav-home', 'events.html':'nav-events', 'members.html':'nav-members' };
  const here = location.pathname.split('/').pop() || 'index.html';
  const id = map[here];
  if (id) { const el = document.getElementById(id); if (el) el.classList.add('active'); }

  // Update footer year automatically
  const y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();

  // If the goal widget elements exist on the page, load site config
  if (document.getElementById('goalAmount')) {
    try{
      const res = await fetch('data/site.json', { cache: 'no-store' });
      const site = await res.json();
      renderGoal(site.goal, site.raised);
      renderKpis(site);
    }catch(e){ console.error('Missing or invalid data/site.json', e); }
  }

  // If an events grid exists, render events from JSON
  if (document.getElementById('eventsGrid')) {
    try{
      const res = await fetch('data/events.json', { cache: 'no-store' });
      const events = await res.json();
      renderEvents(events);
    }catch(e){ console.error('Missing or invalid data/events.json', e); }
  }

  // If a members grid exists, render members from JSON
  if (document.getElementById('membersGrid')) {
    try{
      const res = await fetch('data/members.json', { cache: 'no-store' });
      const members = await res.json();
      renderMembers(members);
    }catch(e){ console.error('Missing or invalid data/members.json', e); }
  }
});

/** Format a number as Canadian dollars (e.g., 1500 -> $1,500) */
function formatMoney(n){ 
  return new Intl.NumberFormat('en-CA', { style:'currency', currency:'CAD', maximumFractionDigits:0 }).format(n); 
}

/** Render the fundraising goal widget */
function renderGoal(goal, raised){
  const goalEl = document.getElementById('goalAmount');
  const raisedEl = document.getElementById('raisedAmount');
  goalEl.textContent = formatMoney(goal);
  raisedEl.textContent = formatMoney(raised);
  const pct = Math.min(100, Math.round((raised/goal)*100)); // prevent >100%
  const bar = document.querySelector('.progress__bar');
  if (bar){ 
    bar.style.width = pct + '%'; 
    bar.setAttribute('aria-valuenow', String(pct)); // assistive tech reads progress
  }
  const pctEl = document.getElementById('goalPct');
  if (pctEl) pctEl.textContent = pct + '%';
}

/** Update KPI counters beneath the hero */
function renderKpis(site){
  const k1 = document.getElementById('kpiEvents'); if (k1) k1.textContent = site.eventsRun || 1;
  const k2 = document.getElementById('kpiVolunteers'); if (k2) k2.textContent = site.volunteers || 10;
  const k3 = document.getElementById('kpiRaised'); if (k3) k3.textContent = formatMoney(site.raised);
}

/** Render an array of event objects as cards */
function renderEvents(events){
  const grid = document.getElementById('eventsGrid');
  grid.innerHTML = ''; // clear any placeholders
  events.forEach(ev => {
    const card = document.createElement('article');
    card.className = 'card event';
    card.innerHTML = `
      <img src="${ev.image || 'assets/event-placeholder.jpg'}" alt="${ev.title}" loading="lazy">
      <div class="meta">${ev.date} • ${ev.location}</div>
      <h3>${ev.title}</h3>
      <p>${ev.description}</p>
    `;
    grid.appendChild(card);
  });
}

/** Render members (founders) as cards */
function renderMembers(members){
  const grid = document.getElementById('membersGrid');
  grid.innerHTML = '';
  members.forEach(m => {
    const card = document.createElement('article');
    card.className = 'card member-card';
    card.innerHTML = `
      <img src="${m.photo || 'assets/member-placeholder.jpg'}" alt="${m.name}" loading="lazy">
      <h3>${m.name}</h3>
      ${m.role ? `<div class="meta">${m.role}</div>`:''}
      <div class="links">
        ${m.linkedin ? `<a href="${m.linkedin}" target="_blank" rel="noopener">LinkedIn</a>`:''}
        ${m.email ? `<a href="mailto:${m.email}">Email</a>`:''}
      </div>
    `;
    grid.appendChild(card);
  });
}
